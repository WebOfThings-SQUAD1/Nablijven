import pygame as pg


def openendscreen():
    havingthisexamninaugust = False



    bg = pg.image.load("./resources/endscene.png")
    bg = pg.transform.scale(bg, (600-50, 800-50))#c.SCREEN_WIDTH/2, c.SCREEN_HEIGHT/2
    screen = pg.display.set_mode((600, 800),pg.FULLSCREEN)#
    screen.blit(bg, (100,100))
    pg.display.flip()

    while not havingthisexamninaugust:
        for exam in pg.event.get():
            if exam.type == pg.QUIT:
                havingthisexamninaugust = True
    pg.quit()

openendscreen()