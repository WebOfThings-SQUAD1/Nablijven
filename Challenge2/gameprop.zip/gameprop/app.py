

import pygame as pg
import paho.mqtt.client as mqtt
import socket

from source.game import main as launchGame
from source.login import openlogin as launchLogin
from source.endscreen import openendscreen as launchEndscreen


# ip adress of broker
MQTT_BROKER = "192.168.50.45"
# login to broker (xcape admin mode)
MQTT_LOGIN = ['admin', '1234']
# path to mqtt inbox for messaging. 
MQTT_INBOX = "Room/squad1/Props/webgame/inbox"
MQTT_OUTBOX = "Room/squad1/Props/webgame/outbox"



# boot app with login
def runDefault():
    if launchLogin():
        launchGame()
        launchEndscreen()
    # runDefault()


herexamen=False
def on_connect(client, userdata, flags, rc):
    global herexamen
    print("Connected: code "+str(rc))

    client.subscribe(MQTT_INBOX)
    try:
        if not herexamen:
            runDefault()
    except Exception as err:
        print('err:',err)
        herexamen=True
    finally:
        print()



def on_message(client, userdata, message):
    msg=message.payload.decode()

    if msg == "Q":
        pg.quit()
        client.diconnect()
    elif msg == "reset":
        pg.quit()
        runDefault()
        print('do reset')
    print('--message:',message)



if __name__=='__main__':
    # you can add a random or specific client Id as string. 
    # Leaving this empty give a clean session so works as well
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    
    client.username_pw_set(username=MQTT_LOGIN[0], password=MQTT_LOGIN[1])

    client.connect(MQTT_BROKER, 1883, 60)

    client.loop_forever()


