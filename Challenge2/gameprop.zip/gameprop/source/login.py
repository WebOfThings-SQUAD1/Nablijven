
import pygame as pg
from math import floor
from . import constants as c


def openlogin():
    screen = pg.display.set_mode(c.SCREEN_SIZE, pg.FULLSCREEN)
    FONT = pg.font.Font(None, 42)
    clock = pg.time.Clock()

    password = ''
    authenticated = False
    textColor=(244, 136, 51)
    textColorDark=(90, 50, 20)

    bgColor=(10,10,10)


    while not authenticated:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                authenticated = True
                continue
            elif event.type == pg.KEYDOWN:
                if event.key == pg.K_RETURN:
                    if password == "partyvelde":
                        authenticated=True
                    password = ''

                elif event.key == pg.K_BACKSPACE:
                    password = password[:-1]

                elif len(password)<10:  
                    password += event.unicode

        tikk= floor(pg.time.get_ticks()/200)
        screen.fill(bgColor)
        password_surface = FONT.render('*'*len(password) if len(password) else 'Enter Password', True, textColor if tikk%4!=0 else textColorDark)
        screen.blit(FONT.render('Login', True, textColor), (30, 30))
        screen.blit(password_surface, (30, 100))
        pg.display.flip()
    return 1
        
    
    # msg='' if len(password) else 'Enter Password'
    # password_surface = FONT.render(msg if tikk%8!=0 else '*'*len(password), True, (70, 200, 150))

    password_surface = FONT.render('*'*len(password) if len(password) else 'Enter Password', True, (244, 136, 51) )

    # screen.blit(bg, (0, 0))
    screen.blit(password_surface, (30, 30))

    pg.display.flip()
    clock.tick(30)

   