import pygame as pg
from . import constants as c


def openendscreen():
    havingthisexamninaugust = False

    bg = pg.image.load("resources/endscene.png")
    bg = pg.transform.scale(bg, c.SCREEN_WIDTH, c.SCREEN_HEIGHT)
    screen = pg.display.set_mode(c.SCREEN_SIZE, pg.FULLSCREEN)
    screen.blit(bg, (0,0))
    pg.display.flip()

    while not havingthisexamninaugust:
        for exam in pg.event.get():
            if exam.type == pg.QUIT:
                havingthisexamninaugust = True
    pg.quit()

