


import paho.mqtt.client as mqtt





def on_connect(client, userdata, flags, rc):    
    client.subscribe("Room/squad1/Props/webgame/inbox")
    
    print("Connected succefully!"+str(rc))



def on_message(client, userdata, message):
    msg=message.payload.decode()

    if msg == "test":
        print("EXECUTE TEST")
    else:
        print('--message:',message)



if __name__=='__main__':
    client = mqtt.Client('webgame')
    client.on_connect = on_connect
    client.on_message = on_message
    
    client.username_pw_set(username='admin',password='1234')
    client.connect('192.168.50.45', 1883, 60)
    client.loop_forever()
