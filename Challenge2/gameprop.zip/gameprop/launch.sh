#!/bin/bash

cd /home/pi/gameprop

conntimeout=0
while [ "$(hostname -I)" = "" ]; do
	if [[ $conntimeout -gt 100 ]];
	then
		./log -e "network  connection timeout!"
        #sudo reboot
		exit 2
	fi
	sleep 2
	((conntimeout++))
done
./log 'Network enable'


python3 /home/pi/gameprop/app.py &
./log 'game started in background'

./disablekeys &
./log 'keys disabeled'
