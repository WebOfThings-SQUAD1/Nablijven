# webgame
A custom [pygame](https://www.pygame.org/wiki/GettingStarted#Pygame%20Installation) version of an [Python Mario Super](https://github.com/marblexu/PythonSuperMario) implementation.

Pygame together with disableling certain keys makes this a fully escape room proof [Kiosk Mode](https://www.raspberrypi.com/tutorials/how-to-use-a-raspberry-pi-in-kiosk-mode/).

In pygame there are commands to exit the fullscreen,
eg : `alt` + `ctrl` + `f1` (or f2, f3..).
So by disabeling alt, ctrl, and f1 , this is not longer an option.

*This is the newest version, see the [commit history](https://github.com/WebOfThings-SQUAD1/Nablijven/commits/main) for NodeJs and other implimentations.*

![gameprop/resources/graphics/gameplay.png](gameprop/resources/graphics/gameplay.png)

## Usage
Download or pull the repo, remove everything except the inside of challenge2.
``` sh
git pull https://github.com/WebOfThings-SQUAD1/Nablijven.git
mv ./Challenge2/gameprop ~/gameprop

cd ~/gameprop
# dependencies
sudo pip install -r requirements.txt
# enable execution of scripts
chmod +x gameprop/launch.sh
chmod +x gameprop/log.sh
chmod +x gameprop/disablekeys.sh

```
You can now delete the other downloaded files. 
The gameprop can now be found at `pi/home/gameprop`.

### configuration:
Change the MQTT_ variables in the [app.py](./gameprop/app.py) to the right IP and Broker.


## start on boot
There are [several ways](https://www.dexterindustries.com/howto/run-a-program-on-your-raspberry-pi-at-startup/) of running a script at startup (in our case the [gameprop/launch.sh](gameprop/launch.sh)).
The most effective way in most cases to create a [service](https://www.makeuseof.com/what-is-systemd-launch-programs-raspberry-pi/).

``` sh
sudo nano /lib/systemd/system/gameprop_service.service
```

Paste the following text:

<ins>Optionally:</ins><br>
You can add `After=network.target` under `[Unit]` to wait for a network connection, but the `launch.sh` does the same thing in a more controllable environment.
```txt

[Unit]
Description=Start webgameprop
After=multi-user.target

[Service]
ExecStart=/home/pi/gameprop/launch.sh &

[Install]
WantedBy=multi-user.target
```
Press `ctrl-s` to save then `ctrl-x` to close.
<br>

To run the service and activate:
```
sudo systemctl start gameprop_service.service.
```
An now reboot (sudo reboot).

You can close the service with:
``` 
sudo systemctl stop gameprop_service.service.
```


<br>

## No broker? No Xcape? MacOs? Test local!
Install the local broker [mosquitty](https://github.com/eclipse/mosquitto).

You can follow their install instructions on [mosquitto.org](https://mosquitto.org/download/).



<br>

## Other
[How to hack pygame?](https://www.pygame.org/wiki/Hacking)